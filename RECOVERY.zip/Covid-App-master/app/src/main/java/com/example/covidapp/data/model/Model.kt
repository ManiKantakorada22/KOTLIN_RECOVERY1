package com.example.covidapp.data.model

class Model(var imageview: Int, var symptomsText: String, var symptomsDetail: String)
