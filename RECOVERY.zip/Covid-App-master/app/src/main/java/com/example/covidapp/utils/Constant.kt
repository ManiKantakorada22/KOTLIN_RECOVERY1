package com.example.covidapp.utils

object Constant {
    const val SWAPNIL_GITHUB = "https://github.com/swapnilsparsh"
    const val SWAPNIL_WEB = "https://swapnilsparsh.github.io/"
    const val SWAPNIL_LINKEDIN = "https://www.linkedin.com/in/swapnil-srivastava-sparsh/"
    const val KNOW_MORE = "https://www.who.int/emergencies/diseases/novel-coronavirus-2019"
}